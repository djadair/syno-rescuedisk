#!/bin/sh

set -e

# This config script provides a method of adjusting the tarball
# contents after multistrap has completed.
# The script is copied into the tarball and unpacked to:
# /config.sh

# This example file can act as a skeleton for your own scripts.
